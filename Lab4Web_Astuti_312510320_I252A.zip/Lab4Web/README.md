# Lab4Web - Praktikum 4: CSS Layout

| | |
|---|---|
| **Nama** | Astuti |
| **NIM** | 312510320 |
| **Kelas** | I252A |
| **Mata Kuliah** | Pemrograman Web |
| **Kampus** | Universitas Pelita Bangsa, Cikarang |

## Struktur Folder

```
Lab4Web/
├── lab4_box.html
├── lab4_layout/
│   ├── home.html
│   ├── artikel.html
│   ├── about.html      <- Tugas 1
│   ├── kontak.html     <- Tugas 2
│   └── style.css
├── screenshots/
└── README.md
```

> Simpan screenshot tiap langkah di folder `screenshots/` lalu ganti nama file pada tautan gambar di bawah.

---

## Bagian 1 - Box Element dan CSS Float (`lab4_box.html`)

**Langkah:**
1. Membuat dokumen HTML dasar dengan `<header>` berisi `<h1>Box Element</h1>`.
2. Menambahkan `<section>` berisi tiga `<div>` (`div1`, `div2`, `div3`).
3. Menambahkan CSS `float: left` dan `padding: 10px` pada `div`, serta warna latar merah, kuning, dan hijau.

**Penjelasan:** Tanpa `float`, setiap `div` tampil memanjang ke bawah (block element). Dengan `float: left`, ketiga `div` mengambang dan tersusun sejajar ke samping.

![Box Element Float](screenshots/01-box-float.png)

## Bagian 2 - Clearfix

**Langkah:** menambahkan `div4` dan CSS berikut.

```css
.div4 {
    background-color: blue;
    clear: left;
    float: none;
}
```

**Penjelasan:** Property `clear` menghentikan pengaruh float sebelumnya sehingga `div4` tampil di baris baru di bawah `div1-div3`.

**Eksperimen nilai `clear`:**

| Nilai | Hasil |
|---|---|
| `left` | `div4` turun di bawah elemen yang float ke kiri |
| `right` | `div4` tidak dipengaruhi float kiri, sehingga tetap berada di sisi elemen float |
| `both` | `div4` turun di bawah semua elemen float (kiri maupun kanan) |

![Clearfix](screenshots/02-clearfix.png)

---

## Bagian 3 - Layout Web Sederhana (`lab4_layout/`)

### 3.1 Kerangka layout dengan HTML5 semantic element
Membuat `home.html` dan `style.css`. Di dalam `<div id="container">` disusun `<header>`, `<nav>`, `<section id="hero">`, `<section id="wrapper">` (berisi `<section id="main">` dan `<aside id="sidebar">`), dan `<footer>`.

![Kerangka Layout](screenshots/03-kerangka.png)

### 3.2 CSS dasar dan header
Reset CSS (`margin: 0; padding: 0`), pengaturan `body`, `#container` selebar 980px di tengah halaman (`margin: 0 auto`), serta styling `header`.

![Header](screenshots/04-header.png)

### 3.3 Navigasi
`nav` diberi warna latar biru, link dibuat `inline-block` dengan padding, dan efek `:hover` / `.active`.

![Navigasi](screenshots/05-navigasi.png)

### 3.4 Hero panel
`<section id="hero">` berisi judul, paragraf, dan tombol "Learn more".

![Hero Panel](screenshots/06-hero.png)

### 3.5 Main dan sidebar
`#main` (640px) dan `#sidebar` (260px) diberi `float: left` sehingga tampil berdampingan (total 980px termasuk padding).

![Main dan Sidebar](screenshots/07-main-sidebar.png)

### 3.6 Sidebar widget
Dua `widget-box` di dalam `<aside>`: daftar link dan teks.

![Widget](screenshots/08-widget.png)

### 3.7 Footer
`footer` memakai `clear: both` supaya berada di bawah elemen yang float.

![Footer](screenshots/09-footer.png)

### 3.8 Konten utama (box) dan artikel
Tiga `.box` selebar 33.33% dengan gambar bulat, lalu dua `<article class="entry">` dengan gambar float kiri dan kanan. Clearfix memakai `.row:after` dan `.entry:after`.

![Konten](screenshots/10-konten.png)
![Artikel](screenshots/11-artikel.png)

---

## Jawaban Pertanyaan dan Tugas

### Tugas 1 - Layout menu About (`about.html`)
Halaman About memakai kerangka layout yang sama dengan `home.html` (header, nav, hero, wrapper, footer). Isi `#main`:
- **Deskripsi** - foto profil (`<img>` float kiri) dan paragraf perkenalan dalam `<article class="entry">`.
- **Portfolio** - tiga `.box` berisi karya praktikum (Box Element, Layout Web, Form Kontak).
- **Keahlian** - progress bar sederhana untuk HTML5, CSS3, dan Git.

Isi `#sidebar`: widget **Data Mahasiswa** (nama, NIM, kelas, kampus) dan **Menu Cepat**.

![About](screenshots/12-about.png)

### Tugas 2 - Layout menu Contact (`kontak.html`)
Halaman Kontak berisi form dengan field **nama, email, no. telepon, subjek (select), dan message (textarea)**, serta tombol Kirim dan Reset. Setiap field dibungkus `.form-group` dengan `<label>` yang terhubung lewat atribut `for`/`id`. Sidebar berisi widget **Informasi Kontak** dan **Catatan**.

![Kontak](screenshots/13-kontak.png)

---

## Validasi HTML
Seluruh file HTML divalidasi dengan Nu Html Checker (mesin yang sama dengan validator.w3.org): 0 error pada semua file.

![Validasi](screenshots/14-validator.png)

## Kesimpulan
Dengan box element, CSS float, clearfix, dan HTML5 semantic element, sebuah layout web dapat disusun menjadi bagian-bagian yang jelas: header, navigasi, konten utama, sidebar, dan footer.
